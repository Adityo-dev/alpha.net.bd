import TestimonialSlider from "./TestimonialSlider";

const testimonialData = [
  {
    companyName: "Tanmoysoft",
    rating: "",
    description:
      "I have been using their domain & hosting services since 2018. I am fully satisfied, they will be providing you great support. 10/10 ",
    name: "tanmoy Debnath",
    moreInfo: "#",
  },
  {
    companyName: "Tanmoysoft",
    rating: "",
    description:
      "I have been using their domain & hosting services since 2018. I am fully satisfied, they will be providing you great support. 10/10 ",
    name: "tanmoy Debnath",
    moreInfo: "#",
  },
  {
    companyName: "Tanmoysoft",
    rating: "",
    description:
      "I have been using their domain & hosting services since 2018. I am fully satisfied, they will be providing you great support. 10/10 ",
    name: "tanmoy Debnath",
    moreInfo: "#",
  },
  {
    companyName: "Tanmoysoft",
    rating: "",
    description:
      "I have been using their domain & hosting services since 2018. I am fully satisfied, they will be providing you great support. 10/10 ",
    name: "tanmoy Debnath",
    moreInfo: "#",
  },
  {
    companyName: "Tanmoysoft",
    rating: "",
    description:
      "I have been using their domain & hosting services since 2018. I am fully satisfied, they will be providing you great support. 10/10 ",
    name: "tanmoy Debnath",
    moreInfo: "#",
  },
  {
    companyName: "Tanmoysoft",
    rating: "",
    description:
      "I have been using their domain & hosting services since 2018. I am fully satisfied, they will be providing you great support. 10/10 ",
    name: "tanmoy Debnath",
    moreInfo: "#",
  },
  {
    companyName: "Tanmoysoft",
    rating: "",
    description:
      "I have been using their domain & hosting services since 2018. I am fully satisfied, they will be providing you great support. 10/10 ",
    name: "tanmoy Debnath",
    moreInfo: "#",
  },
  {
    companyName: "Tanmoysoft",
    rating: "",
    description:
      "I have been using their domain & hosting services since 2018. I am fully satisfied, they will be providing you great support. 10/10 ",
    name: "tanmoy Debnath",
    moreInfo: "#",
  },
];

function Testimonial() {
  return (
    <main>
      <TestimonialSlider testimonialData={testimonialData} />
    </main>
  );
}

export default Testimonial;
