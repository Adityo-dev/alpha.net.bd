import React from "react";

const GoogleMap = () => {
  return <></>;
};

export default GoogleMap;
