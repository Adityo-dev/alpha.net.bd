function TermsOfService() {
  return (
    <div className="container mx-auto px-3 lg:px-6">
      <p>TermsOfService</p>
    </div>
  );
}

export default TermsOfService;
