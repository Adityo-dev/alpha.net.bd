(()=>{var e={};e.id=920,e.ids=[920],e.modules={846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},9121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},9294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},3033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},3873:e=>{"use strict";e.exports=require("path")},9551:e=>{"use strict";e.exports=require("url")},7230:(e,t,a)=>{"use strict";a.r(t),a.d(t,{GlobalError:()=>o.a,__next_app__:()=>m,pages:()=>c,routeModule:()=>u,tree:()=>d});var s=a(260),n=a(8203),r=a(5155),o=a.n(r),i=a(7292),l={};for(let e in i)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>i[e]);a.d(t,l);let d=["",{children:["contact-us",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,8127)),"D:\\ECOYSOFT WEB PROJECT\\alpha.net.bd\\src\\app\\contact-us\\page.js"]}]},{metadata:{icon:[async e=>(await Promise.resolve().then(a.bind(a,440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(a.bind(a,257)),"D:\\ECOYSOFT WEB PROJECT\\alpha.net.bd\\src\\app\\layout.js"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,9937,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(a.t.bind(a,9116,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(a.t.bind(a,1485,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(a.bind(a,440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],c=["D:\\ECOYSOFT WEB PROJECT\\alpha.net.bd\\src\\app\\contact-us\\page.js"],m={require:a,loadChunk:()=>Promise.resolve()},u=new s.AppPageRouteModule({definition:{kind:n.RouteKind.APP_PAGE,page:"/contact-us/page",pathname:"/contact-us",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},2102:(e,t,a)=>{Promise.resolve().then(a.t.bind(a,1066,23)),Promise.resolve().then(a.t.bind(a,6193,23)),Promise.resolve().then(a.bind(a,3092)),Promise.resolve().then(a.bind(a,9114))},3726:(e,t,a)=>{Promise.resolve().then(a.t.bind(a,1902,23)),Promise.resolve().then(a.bind(a,8661)),Promise.resolve().then(a.bind(a,4721)),Promise.resolve().then(a.bind(a,3430))},8661:(e,t,a)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0});var s=a(8009),n=function(e){return e&&"object"==typeof e&&"default"in e?e:{default:e}}(s);let r=s.forwardRef(function({style:e={},className:t="",autoFill:a=!1,play:r=!0,pauseOnHover:o=!1,pauseOnClick:i=!1,direction:l="left",speed:d=50,delay:c=0,loop:m=0,gradient:u=!1,gradientColor:p="white",gradientWidth:h=200,onFinish:f,onCycleComplete:x,onMount:g,children:b},v){let[j,w]=s.useState(0),[y,N]=s.useState(0),[k,C]=s.useState(1),[E,P]=s.useState(!1),O=s.useRef(null),B=v||O,M=s.useRef(null),S=s.useCallback(()=>{if(M.current&&B.current){let e=B.current.getBoundingClientRect(),t=M.current.getBoundingClientRect(),s=e.width,n=t.width;("up"===l||"down"===l)&&(s=e.height,n=t.height),a&&s&&n?C(n<s?Math.ceil(s/n):1):C(1),w(s),N(n)}},[a,B,l]);s.useEffect(()=>{if(E&&(S(),M.current&&B.current)){let e=new ResizeObserver(()=>S());return e.observe(B.current),e.observe(M.current),()=>{e&&e.disconnect()}}},[S,B,E]),s.useEffect(()=>{S()},[S,b]),s.useEffect(()=>{P(!0)},[]),s.useEffect(()=>{"function"==typeof g&&g()},[]);let T=s.useMemo(()=>a?y*k/d:y<j?j/d:y/d,[a,j,y,k,d]),D=s.useMemo(()=>Object.assign(Object.assign({},e),{"--pause-on-hover":!r||o?"paused":"running","--pause-on-click":!r||o&&!i||i?"paused":"running","--width":"up"===l||"down"===l?"100vh":"100%","--transform":"up"===l?"rotate(-90deg)":"down"===l?"rotate(90deg)":"none"}),[e,r,o,i,l]),F=s.useMemo(()=>({"--gradient-color":p,"--gradient-width":"number"==typeof h?`${h}px`:h}),[p,h]),q=s.useMemo(()=>({"--play":r?"running":"paused","--direction":"left"===l?"normal":"reverse","--duration":`${T}s`,"--delay":`${c}s`,"--iteration-count":m?`${m}`:"infinite","--min-width":a?"auto":"100%"}),[r,l,T,c,m,a]),A=s.useMemo(()=>({"--transform":"up"===l?"rotate(90deg)":"down"===l?"rotate(-90deg)":"none"}),[l]),z=s.useCallback(e=>[...Array(Number.isFinite(e)&&e>=0?e:0)].map((e,t)=>n.default.createElement(s.Fragment,{key:t},s.Children.map(b,e=>n.default.createElement("div",{style:A,className:"rfm-child"},e)))),[A,b]);return E?n.default.createElement("div",{ref:B,style:D,className:"rfm-marquee-container "+t},u&&n.default.createElement("div",{style:F,className:"rfm-overlay"}),n.default.createElement("div",{className:"rfm-marquee",style:q,onAnimationIteration:x,onAnimationEnd:f},n.default.createElement("div",{className:"rfm-initial-child-container",ref:M},s.Children.map(b,e=>n.default.createElement("div",{style:A,className:"rfm-child"},e))),z(k-1)),n.default.createElement("div",{className:"rfm-marquee",style:q},z(k))):null});t.default=r},4721:(e,t,a)=>{"use strict";a.d(t,{default:()=>m});var s=a(5512),n=a(8866),r=a(1680);let o=(0,r.A)("MapPin",[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]]),i=(0,r.A)("MapPinPlus",[["path",{d:"M19.914 11.105A7.298 7.298 0 0 0 20 10a8 8 0 0 0-16 0c0 4.993 5.539 10.193 7.399 11.799a1 1 0 0 0 1.202 0 32 32 0 0 0 .824-.738",key:"fcdtly"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}],["path",{d:"M16 18h6",key:"987eiv"}],["path",{d:"M19 15v6",key:"10aioa"}]]);var l=a(8531),d=a.n(l),c=a(8009);function m(){let[e,t]=(0,c.useState)(!1),a=async e=>{e.preventDefault(),t(!0);let a=Object.fromEntries(new FormData(e.target).entries()),s=`
  <!DOCTYPE html>
  <html>
  <head>
    <style>
      body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        background-color: #f9f9f9;
        margin: 0;
        padding: 0;
      }
      .email-container {
        max-width: 600px;
        margin: 20px auto;
        background: #ffffff;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        overflow: hidden;
      }
      .header {
        background-color: #0948B3;
        color: #ffffff;
        padding: 15px;
        text-align: center;
        font-size: 18px;
        font-weight: bold;
      }
      .content {
        padding: 20px;
        color: #333;
      }
      .footer {
        text-align: center;
        font-size: 14px;
        color: #777;
        padding: 10px;
        background: #f1f1f1;
      }
      .footer a {
        color: #0948B3;
        text-decoration: none;
      }
    </style>
  </head>
  <body>
    <div class="email-container">
      <div class="header">Thank You for Contacting DiniSoftBD</div>
      <div class="content">
        <p>Hi <strong>${a.email}</strong>,</p>
        <p>
          Thank you for reaching out to us with the subject: <strong>${a.subject}</strong>.
          We have received your message and will respond to your inquiry shortly.
        </p>
        <p>If you have additional questions, feel free to reply to this email.</p>
        <p>Regards,</p>
        <p><strong>DiniSoftBD Team</strong></p>
      </div>
      <div class="footer">
        \xa9 2025 DiniSoftBD | <a href="https://dinisoftbd.com">Visit Our Website</a>
      </div>
    </div>
  </body>
  </html>
`,n=`
  <!DOCTYPE html>
  <html>
  <head>
    <style>
      body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        background-color: #f9f9f9;
        margin: 0;
        padding: 0;
      }
      .email-container {
        max-width: 600px;
        margin: 20px auto;
        background: #ffffff;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        overflow: hidden;
      }
      .header {
        background-color: #FF5722;
        color: #ffffff;
        padding: 15px;
        text-align: center;
        font-size: 18px;
        font-weight: bold;
      }
      .content {
        padding: 20px;
        color: #333;
      }
      .footer {
        text-align: center;
        font-size: 14px;
        color: #777;
        padding: 10px;
        background: #f1f1f1;
      }
      .footer a {
        color: #FF5722;
        text-decoration: none;
      }
    </style>
  </head>
  <body>
    <div class="email-container">
      <div class="header">New Message Received</div>
      <div class="content">
        <p><strong>Subject:</strong> ${a.subject}</p>
        <p><strong>Email:</strong> ${a.email}</p>
        <p><strong>Message:</strong></p>
        <p>${a.message}</p>
        <p>
          Please follow up promptly with the sender to address their inquiry.
        </p>
      </div>
      <div class="footer">
        \xa9 2025 DiniSoftBD | <a href="https://dinisoftbd.com">Admin Panel</a>
      </div>
    </div>
  </body>
  </html>
`;try{let e=await fetch("/api/sendmail",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({to:a.email,subject:`Confirmation: ${a.subject}`,text:a.subject,html:s})}),r=await fetch("/api/sendmail",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({to:"sales@dinisoftbd.com",subject:`New Inquiry: ${a.subject}`,text:a.subject,html:n})});e.ok&&r.ok?(alert("Your message has been sent successfully!"),t(!1)):(t(!1),alert("Failed to send the message. Please try again later."))}catch(e){t(!1),console.error("Error sending emails:",e),alert("An error occurred. Please try again.")}};return(0,s.jsx)("div",{className:"container mx-auto px-3 lg:px-6",children:(0,s.jsxs)("div",{className:"grid grid-cols-12",children:[(0,s.jsxs)("div",{className:"col-span-12 lg:col-span-8 rounded-lg px-3 py-6 lg:p-10 shadow-sm bg-[#FAFAFA]",children:[(0,s.jsx)("h2",{className:"mb-6 text-2xl font-bold text-gray-900",children:"Send Us a Message"}),(0,s.jsxs)("form",{className:"space-y-4",onSubmit:a,children:[(0,s.jsx)("div",{children:(0,s.jsx)("input",{type:"text",name:"subject",placeholder:"Enter Subject",className:"w-full rounded-md border border-gray-300 px-4 py-3 focus:border-blue-500 outline-none transition-all duration-300 focus:ring-blue-500",required:!0})}),(0,s.jsx)("div",{children:(0,s.jsx)("input",{type:"email",name:"email",placeholder:"Enter email",className:"w-full rounded-md border border-gray-300 px-4 py-3 focus:border-blue-500 outline-none transition-all duration-300 focus:ring-blue-500",required:!0})}),(0,s.jsx)("div",{children:(0,s.jsx)("textarea",{placeholder:"Message",name:"message",rows:6,className:"w-full rounded-md border border-gray-300 px-4 py-3 focus:border-blue-500 outline-none transition-all duration-300 focus:ring-blue-500",required:!0})}),(0,s.jsx)("button",{type:"submit",disabled:e,className:"rounded-md bg-blue-600 px-6 py-2 text-white transition-colors hover:bg-blue-700 outline-none focus:ring-blue-500 focus:ring-offset-2",children:e?"Sending...":"Send Message"})]})]}),(0,s.jsxs)("div",{className:"col-span-12 lg:col-span-4 rounded-lg bg-[#0948B3] p-8 text-white shadow-lg",children:[(0,s.jsx)("h2",{className:"mb-6 text-2xl font-bold",children:"Looking for a excellent Business idea?"}),(0,s.jsx)("p",{className:"mb-8",children:"Drop by anytime, we endeavour to answer all enquiries within 24 hours on business days."}),(0,s.jsxs)("div",{className:"space-y-6",children:[(0,s.jsxs)("div",{className:"flex items-center space-x-4",children:[(0,s.jsx)(i,{size:28}),(0,s.jsxs)("div",{children:[(0,s.jsx)("h3",{className:"font-semibold",children:"Company Location"}),(0,s.jsxs)("p",{className:"text-sm text-white/90",children:[(0,s.jsx)("b",{children:"DINISOFT BD"})," ",(0,s.jsx)("br",{})," Modern Moor, (Mutual Trust Bank Market), Ghashiapara Road, Dinajpur,\xa0Banglaedesh"]}),(0,s.jsxs)(d(),{className:" w-fit mt-2 flex items-center gap-2 px-2 py-1 bg-gradient-to-r from-purple-600 to-blue-500 hover:from-blue-500 text-white font-bold text-sm rounded-full shadow-lg  transition-all",href:"https://maps.app.goo.gl/yu97x7jA772jekqBA",target:"_blank",children:[(0,s.jsx)(o,{className:"w-4 h-4"})," DC Location"]})]})]}),(0,s.jsxs)("div",{className:"flex items-center space-x-4",children:[(0,s.jsx)(n.A,{size:22}),(0,s.jsxs)("div",{children:[(0,s.jsx)("h3",{className:"font-semibold",children:"Email Address"}),(0,s.jsx)("p",{className:"text-sm text-white/90",children:"sales@dinisoftbd.com"})]})]})]})]})]})})}},3430:(e,t,a)=>{"use strict";a.d(t,{default:()=>n});var s=a(5512);function n(){return(0,s.jsx)("div",{className:"container mx-auto px-3 lg:px-6",children:(0,s.jsxs)("div",{className:"grid gap-6 md:grid-cols-3",children:[(0,s.jsx)("div",{className:"rounded-lg border border-gray-200 bg-white p-6 shadow-sm transition-shadow hover:shadow-md",children:(0,s.jsxs)("div",{className:"flex flex-col items-center text-center",children:[(0,s.jsx)("div",{className:"mb-4 text-blue-600",children:(0,s.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",className:"h-8 w-8",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",children:(0,s.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"})})}),(0,s.jsx)("h3",{className:"mb-3 text-xl font-semibold text-gray-900",children:"Mail Us"}),(0,s.jsx)("p",{className:"mb-2 text-sm text-gray-600",children:"Say something to start a live chat"}),(0,s.jsx)("a",{href:"mailto:sales@dinisoftbd.com",className:"text-sm text-blue-600",children:"sales@dinisoftbd.com"}),(0,s.jsx)("a",{href:"tel:+8801788800151",className:"text-sm text-blue-600",children:"+8801788800151"})]})}),(0,s.jsx)("div",{className:"rounded-lg border border-gray-200 bg-white p-6 shadow-sm transition-shadow hover:shadow-md",children:(0,s.jsxs)("div",{className:"flex flex-col items-center text-center",children:[(0,s.jsx)("div",{className:"mb-4 text-blue-600",children:(0,s.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",className:"h-8 w-8",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",children:(0,s.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 18v-6a9 9 0 0118 0v6m-18 0h18M6 21h12a2 2 0 002-2v-1H4v1a2 2 0 002 2z"})})}),(0,s.jsx)("h3",{className:"mb-3 text-xl font-semibold text-gray-900",children:"24/7 Live Chat"}),(0,s.jsx)("p",{className:"text-sm text-gray-600",children:"We endeavour to answer all enquiries within 24 hours on business days."}),(0,s.jsxs)("button",{className:"flex items-center gap-2 font-semibold hover:bg-blue-500 hover:text-white text-sm text-blue-600 bg-blue-100 px-2 py-1 rounded-lg mt-2 transition-all duration-500",onClick:()=>{if(!window.Tawk_API){var e=document.createElement("script");e.async=!0,e.src="https://embed.tawk.to/55a81f9b84d307454c027a34/default",e.charset="UTF-8",e.setAttribute("crossorigin","*"),document.body.appendChild(e)}},children:[(0,s.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor",width:"20",height:"20",children:(0,s.jsx)("path",{d:"M12 2C6.48 2 2 6.03 2 11c0 2.2 1 4.21 2.65 5.74L3 21l4.48-1.88C8.62 20.36 10.24 21 12 21c5.52 0 10-4.03 10-9s-4.48-9-10-9zm0 16c-1.45 0-2.81-.4-3.98-1.09L5 18l.91-2.85C4.37 13.93 4 12.51 4 11c0-4.07 3.59-7 8-7s8 2.93 8 7-3.59 7-8 7z"})}),"Live Chat"]})]})}),(0,s.jsx)("div",{className:"rounded-lg border border-gray-200 bg-white p-6 shadow-sm transition-shadow hover:shadow-md",children:(0,s.jsxs)("div",{className:"flex flex-col items-center text-center",children:[(0,s.jsx)("div",{className:"mb-4 text-blue-600",children:(0,s.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",className:"h-8 w-8",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",children:[(0,s.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"}),(0,s.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M15 11a3 3 0 11-6 0 3 3 0 016 0z"})]})}),(0,s.jsx)("h3",{className:"mb-3 text-xl font-semibold text-gray-900",children:"Visit Us"}),(0,s.jsx)("p",{className:"text-sm text-gray-600",children:"Modern Moor, (Mutual Trust Bank Market), Ghashiapara Road, Dinajpur,\xa0Banglaedesh"})]})})]})})}},6193:(e,t,a)=>{let{createProxy:s}=a(3439);e.exports=s("D:\\ECOYSOFT WEB PROJECT\\alpha.net.bd\\node_modules\\react-fast-marquee\\dist\\index.js")},8127:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>m});var s=a(2740),n=a(5635),r=a(6193),o=a.n(r);let i=[{image:"/BD.png",name:"Bangladesh"},{image:"/Brazil.png",name:"Brazil"},{image:"/BD.png",name:"Bangladesh"},{image:"/France.png",name:"France"},{image:"/India.png",name:"India"},{image:"/Pakistan.png",name:"Pakistan"},{image:"/Germany.png",name:"Germany"},{image:"/BD.png",name:"Bangladesh"},{image:"/France.png",name:"France"},{image:"/Newzealand.png",name:"Newzealand"},{image:"/Spain.png",name:"Spain"},{image:"/BD.png",name:"Bangladesh"},{image:"/Pakistan.png",name:"Pakistan"},{image:"/Newzealand.png",name:"Newzealand"}],l=function(){return(0,s.jsx)("div",{children:(0,s.jsx)(o(),{speed:60,direction:"left",pauseOnHover:!0,gradient:!0,gradientWidth:50,children:i.map((e,t)=>(0,s.jsxs)("div",{className:"w-[200px] lg:w-[250px] flex items-center gap-3 shadow-lg p-3 lg:p-4 rounded-md mr-3 lg:mr-6 border transition-all duration-300 hover:border-[#80a4d9]",children:[(0,s.jsx)(n.default,{src:e?.image,width:400,height:400,alt:e?.name,className:"max-w-12 lg:max-w-16 w-full h-full"}),(0,s.jsx)("p",{children:e?.name})]},t))})})};var d=a(3092),c=a(9114);a(6301);let m=function(){return(0,s.jsxs)("main",{className:"space-y-6 sm:space-y-12",children:[(0,s.jsx)("div",{className:"bg-[#014cda]",style:{backgroundImage:"url('https://dinisoftbd.com/wp-content/uploads/2023/09/tos.jpeg')",backgroundSize:"cover",backgroundPosition:"center",backgroundBlendMode:"overlay"},children:(0,s.jsxs)("div",{className:"container mx-auto px-3 lg:px-6 w-full h-64 md:h-80 flex flex-col items-center justify-center text-white text-center space-y-4 py-8",children:[(0,s.jsx)("h1",{className:"text-4xl font-bold",children:"Contact Us"}),(0,s.jsx)("p",{className:"text-base sm:text-lg w-full md:w-2/3 mx-auto ",children:"Web hosting made easy & affordable, choose a fine-tuned web hosting services solution for successful personal and business websites."})]})}),(0,s.jsx)(c.default,{}),(0,s.jsx)(d.default,{}),(0,s.jsxs)("div",{className:"space-y-6",children:[(0,s.jsx)("h1",{className:"bg-[#EBF3FF] text-[#204674] text-center py-2 font-semibold text-xl border-t border-b border-[#80a4d9]",children:"Location Of Our Clients"}),(0,s.jsx)("div",{className:"container mx-auto px-3 lg:px-6",children:(0,s.jsx)(l,{})})]})]})}},3092:(e,t,a)=>{"use strict";a.d(t,{default:()=>s});let s=(0,a(6760).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\ECOYSOFT WEB PROJECT\\\\alpha.net.bd\\\\src\\\\components\\\\contact\\\\ContactForm.js\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\ECOYSOFT WEB PROJECT\\alpha.net.bd\\src\\components\\contact\\ContactForm.js","default")},9114:(e,t,a)=>{"use strict";a.d(t,{default:()=>s});let s=(0,a(6760).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\ECOYSOFT WEB PROJECT\\\\alpha.net.bd\\\\src\\\\components\\\\contact\\\\ContactInfo.js\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\ECOYSOFT WEB PROJECT\\alpha.net.bd\\src\\components\\contact\\ContactInfo.js","default")},440:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>n});var s=a(8077);let n=async e=>[{type:"image/x-icon",sizes:"32x14",url:(0,s.fillMetadataSegment)(".",await e.params,"favicon.ico")+""}]}};var t=require("../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),s=t.X(0,[994,265,77,805],()=>a(7230));module.exports=s})();